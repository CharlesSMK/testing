### Credit to:

CodeIgniter: https://codeigniter.com/

Bootstrap: https://getbootstrap.com/

Font Awesome: https://fontawesome.com/

SweetAlert2: https://sweetalert2.github.io/
